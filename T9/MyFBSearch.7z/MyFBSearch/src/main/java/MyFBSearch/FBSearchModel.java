package MyFBSearch;

import com.restfb.Connection;
import com.restfb.DefaultFacebookClient;
import com.restfb.FacebookClient;
import com.restfb.Parameter;
import com.restfb.Version;
import com.restfb.exception.FacebookOAuthException;
import com.restfb.types.User;
import java.net.MalformedURLException;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FBSearchModel extends Thread{ //Classe para busca
    
    private FBSearcherController controller;
    private TableModelFBUser model;
    private FBSearchView view;
   
    public FBSearchModel(){
    }
    
    public FBSearchModel(FBSearcherController controller, TableModelFBUser model, FBSearchView view){
        this.controller = controller;
        this.model = model;
        this.view = view;
    }
    
    public void run(){ //Busca
        try{
            String search = view.getTFSearch().getText();
            String token = view.getTFToken().getText();
    
            ArrayList<FBUser> users = model.getList(); //Pego o ArrayList atual para receber o tamanho
        
            FacebookClient fbClient = new DefaultFacebookClient(token, Version.VERSION_2_6);
          
            Connection<User> usuarios = fbClient.fetchConnection("search", User.class, Parameter.with("q", search), Parameter.with("type", "user"), Parameter.with("limit", 5000)); //Recebe valores que contenham o campo search que sejam do tipo usuário(limite de 5000)
        
            for(int i = 0; i < usuarios.getData().size(); i++){ //Verificação do nome(se o nome realmente contém o valor do campo search
                if(usuarios.getData().get(i).getName().contains(search)){
                    controller.insert(usuarios.getData().get(i).getId(), usuarios.getData().get(i).getName(), users.size()+1); //Insiro na tabela e no ArrayList
                }
            }
        } catch (MalformedURLException ex) { //Erro URL
            Logger.getLogger(FBSearchModel.class.getName()).log(Level.SEVERE, null, ex);
        } catch (FacebookOAuthException e){ //Erro de campo token vazio
            view.showError("Dado(s) de entrada invalido(s)!");
        }
    }
}