package MyFBSearch;

import java.util.ArrayList;
import javax.swing.table.AbstractTableModel;

/*class Renderer extends DefaultTableCellRenderer{ //Tentei utilizar este Renderer para adicionar imagens
    JLabel lb1 = new JLabel("");
    TableModelFBUser model = new TableModelFBUser();
    FBUser user;
        
    @Override
    public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int Row, int Column){
        
        FBUser user = (FBUser) model.getList().get(Row);
        try { //Só adiciona o link
            lb1.setIcon(new ImageIcon(new URL("http://graph.facebook.com/" + user.getId() + "/picture?type=large")));
        } catch (MalformedURLException ex) {
            Logger.getLogger(Renderer.class.getName()).log(Level.SEVERE, null, ex);
        }
            
        return lb1;
    }
}*/ //Tentativa de Renderer que bugava por causa do OutOfBoudsException

public class TableModelFBUser extends AbstractTableModel{

    private static final String[] nomesColunas = {"#", "Picture", "Id", "Name"};

    ArrayList<FBUser> users;

    public TableModelFBUser(){
        users = new ArrayList<FBUser>();
    }

    public void add(FBUser u){
        users.add(u);
        fireTableRowsInserted(users.size()-1, users.size()-1);
    }
    
    public ArrayList getList(){
        return users;
    }
    
    public void setList(ArrayList users){
        this.users = users;
    }

    @Override
    public Object getValueAt(int rowIndex, int columnIndex){
        switch(columnIndex){
            case 0: return users.get(rowIndex).getNum();
            case 1: return users.get(rowIndex).getFoto();
            case 2: return users.get(rowIndex).getId();
            case 3: return users.get(rowIndex).getNome();
        }
        return null;
    }
    
    @Override
    public int getColumnCount(){
        return nomesColunas.length;
    }

    @Override
    public String getColumnName(int columnIndex){
        return nomesColunas[columnIndex];
    }

    @Override
    public int getRowCount(){
        return users.size();
    }
}