package MyFBSearch;

import java.net.MalformedURLException;
import java.net.URL;
import javax.swing.ImageIcon;

public class FBSearcherController{

    private FBSearchView view;
    private TableModelFBUser model;

    public FBSearcherController(FBSearchView view, TableModelFBUser model){
        this.view = view;
        this.model = model;
    }

    public void insert(String id, String nome, int num) throws MalformedURLException{
        FBUser user = newFromView(id, nome, num);
        if (user != null){
            model.add(user);
        }
    }

    public void clear(){
        view.getTFToken().setText("");
        view.getTFSearch().setText("");
    }

    private FBUser newFromView(String id, String nome, int num) throws MalformedURLException{
        try{
            FBUser user = new FBUser();
            user.setNum(num);
            user.setFoto(new ImageIcon(new URL("http://graph.facebook.com/" + id + "/picture?type=large")));
            user.setId(id);
            user.setNome(nome);
            return user;
        } catch (NumberFormatException e){
            view.showError("Dado(s) de entrada inválido(s)!");
            return null;
        }
    }
}