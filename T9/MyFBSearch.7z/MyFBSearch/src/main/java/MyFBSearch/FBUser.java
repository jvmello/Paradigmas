package MyFBSearch;

import java.net.*;
import javax.swing.ImageIcon;

public class FBUser{
    //Usuário a ser inserido
    private int num;
    private String id;
    private String nome;
    private ImageIcon foto;

    public FBUser(){
    }
    
    public FBUser(int num, String id, String nome) throws MalformedURLException{
        this.num = num;
        this.id = id;
        this.nome = nome;
        this.foto = new ImageIcon(new URL("http://graph.facebook.com/" + this.id + "/picture?type=large")); //Pega o ID do usuário e busca para ter a imagem
    }

    public int getNum(){
        return num;
    }

    public void setNum(int num){
        this.num = num;
    }

    public String getNome(){
        return nome;
    }

    public void setNome(String nome){
        this.nome = nome;
    }

    public String getId(){
        return id;
    }

    public void setId(String id){
        this.id = id;
    }

    public ImageIcon getFoto(){ //Tentei usar ImageIcon's para fotos mas ele não mostra mesmo assim
        return foto;
    }

    public void setFoto(ImageIcon foto){
        this.foto = foto;
    }
}