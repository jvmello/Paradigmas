package MyFBSearch;

import java.awt.Color;
import java.util.*;
import javax.swing.*;

public class FBSearchView extends javax.swing.JFrame{

    private TableModelFBUser fbSearchModel;
    private FBSearcherController controller;
    private FBSearchModel SearchModel;
    private ArrayList<String> ids;
    
    public FBSearchView(){
        this.ids = new ArrayList<>();
        initComponents();
        
        //Não consegui adicionar os ImageIcon's, aparecem apenas os endereços
        
        fbSearchModel = new TableModelFBUser();
        
        FBTable.setModel(fbSearchModel);
        FBTable.setRowHeight(80); //Tamanhos de linhas e coluna
        FBTable.getColumnModel().getColumn(0).setMaxWidth(30);
        FBTable.getColumnModel().getColumn(1).setMaxWidth(180);
        FBTable.getColumnModel().getColumn(2).setMaxWidth(250);
        FBTable.getColumnModel().getColumn(3).setMaxWidth(150);
        
        controller = new FBSearcherController(this, fbSearchModel);
        
        SearchModel = new FBSearchModel(controller, fbSearchModel, this);
    }

    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jPanel1 = new javax.swing.JPanel();
        tfToken = new javax.swing.JTextField();
        tfSearch = new javax.swing.JTextField();
        labelToken = new javax.swing.JLabel();
        labelSearch = new javax.swing.JLabel();
        BCancel = new javax.swing.JButton();
        BSearch = new javax.swing.JButton();
        jScrollPane4 = new javax.swing.JScrollPane();
        FBTable = new javax.swing.JTable();
        bSave = new javax.swing.JButton();
        jLabel4 = new javax.swing.JLabel();

        setDefaultCloseOperation(javax.swing.WindowConstants.EXIT_ON_CLOSE);

        jPanel1.setBorder(new javax.swing.border.LineBorder(new java.awt.Color(0, 0, 0), 1, true));
        jPanel1.setForeground(new java.awt.Color(230, 230, 230));

        tfToken.setForeground(new java.awt.Color(204, 204, 204));
        tfToken.setText("Token");
        tfToken.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tfTokenMousePressed(evt);
            }
        });

        tfSearch.setForeground(new java.awt.Color(204, 204, 204));
        tfSearch.setText("Name");
        tfSearch.addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                tfSearchMousePressed(evt);
            }
        });

        labelToken.setText("Token");

        labelSearch.setText("Search User");

        BCancel.setText("Cancel");
        BCancel.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BCancelActionPerformed(evt);
            }
        });

        BSearch.setText("Search");
        BSearch.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                BSearchActionPerformed(evt);
            }
        });

        javax.swing.GroupLayout jPanel1Layout = new javax.swing.GroupLayout(jPanel1);
        jPanel1.setLayout(jPanel1Layout);
        jPanel1Layout.setHorizontalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addContainerGap(18, Short.MAX_VALUE)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(labelToken, javax.swing.GroupLayout.Alignment.TRAILING)
                    .addComponent(labelSearch, javax.swing.GroupLayout.Alignment.TRAILING))
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING, false)
                    .addGroup(jPanel1Layout.createSequentialGroup()
                        .addComponent(tfSearch, javax.swing.GroupLayout.PREFERRED_SIZE, 187, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BSearch)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                        .addComponent(BCancel))
                    .addComponent(tfToken))
                .addContainerGap())
        );
        jPanel1Layout.setVerticalGroup(
            jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(jPanel1Layout.createSequentialGroup()
                .addGap(12, 12, 12)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(tfToken)
                    .addComponent(labelToken, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                .addGap(18, 18, 18)
                .addGroup(jPanel1Layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(tfSearch, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(labelSearch, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addComponent(BCancel)
                    .addComponent(BSearch))
                .addGap(10, 10, 10))
        );

        FBTable.setModel(new javax.swing.table.DefaultTableModel(
            new Object [][] {
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null},
                {null, null, null, null}
            },
            new String [] {
                "Title 1", "Title 2", "Title 3", "Title 4"
            }
        ) {
            Class[] types = new Class [] {
                java.lang.Integer.class, java.lang.Object.class, java.lang.Integer.class, java.lang.String.class
            };
            boolean[] canEdit = new boolean [] {
                false, false, false, false
            };

            public Class getColumnClass(int columnIndex) {
                return types [columnIndex];
            }

            public boolean isCellEditable(int rowIndex, int columnIndex) {
                return canEdit [columnIndex];
            }
        });
        FBTable.setAutoResizeMode(javax.swing.JTable.AUTO_RESIZE_ALL_COLUMNS);
        jScrollPane4.setViewportView(FBTable);

        bSave.setText("Save");

        jLabel4.setIcon(new javax.swing.ImageIcon("C:\\Users\\João Vitor\\Documents\\NetBeansProjects\\MyFBSearch\\src\\main\\java\\MyFBSearch\\myfbsearch.gif")); // NOI18N
        jLabel4.setText("MyFBSearch");
        jLabel4.setMaximumSize(new java.awt.Dimension(106, 24));
        jLabel4.setMinimumSize(new java.awt.Dimension(106, 24));

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addContainerGap()
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addComponent(jScrollPane4, javax.swing.GroupLayout.PREFERRED_SIZE, 0, Short.MAX_VALUE)
                    .addComponent(jPanel1, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
                    .addGroup(javax.swing.GroupLayout.Alignment.TRAILING, layout.createSequentialGroup()
                        .addGap(0, 370, Short.MAX_VALUE)
                        .addComponent(bSave))
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 107, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(0, 0, Short.MAX_VALUE)))
                .addContainerGap())
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addComponent(jLabel4, javax.swing.GroupLayout.PREFERRED_SIZE, 24, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addGap(1, 1, 1)
                .addComponent(jPanel1, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                .addComponent(jScrollPane4, javax.swing.GroupLayout.DEFAULT_SIZE, 227, Short.MAX_VALUE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED)
                .addComponent(bSave)
                .addContainerGap())
        );

        pack();
    }// </editor-fold>//GEN-END:initComponents

    private void tfTokenMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tfTokenMousePressed
        if(tfToken.getText() == "" || tfToken.getText() == "Token"){ // não entendi mas deu errado
            tfToken.setText("");
        }
        tfToken.setForeground(Color.BLACK);
    }//GEN-LAST:event_tfTokenMousePressed

    private void BCancelActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BCancelActionPerformed
        SearchModel.stop(); //Thread não para mesmo assim, método deprecated mas foi o único que achei
    }//GEN-LAST:event_BCancelActionPerformed

    private void BSearchActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_BSearchActionPerformed
        SearchModel.run();
    }//GEN-LAST:event_BSearchActionPerformed

    private void tfSearchMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_tfSearchMousePressed
        if(tfSearch.getText() == "" || tfSearch.getText() == "Search"){ // não entendi mas deu errado²
            tfSearch.setText("");
        }
        tfSearch.setForeground(Color.BLACK);
    }//GEN-LAST:event_tfSearchMousePressed
    
    public JTable getFBTable(){
        return FBTable;
    }

    public JTextField getTFToken(){
        return tfToken;
    }

    public JTextField getTFSearch(){
        return tfSearch;
    }
    
    public void showError(String msg){
        JOptionPane.showMessageDialog(this, msg);
    }
    
    public void setFBTable(JTable FBTable){
        this.FBTable = FBTable;
    }
    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JButton BCancel;
    private javax.swing.JButton BSearch;
    private javax.swing.JTable FBTable;
    private javax.swing.JButton bSave;
    private javax.swing.JLabel jLabel4;
    private javax.swing.JPanel jPanel1;
    private javax.swing.JScrollPane jScrollPane4;
    private javax.swing.JLabel labelSearch;
    private javax.swing.JLabel labelToken;
    private javax.swing.JTextField tfSearch;
    private javax.swing.JTextField tfToken;
    // End of variables declaration//GEN-END:variables
}
